#!/usr/bin/env python3
"""Оптимизация арта VICE WORDS: ресайз + WebP для лёгкой загрузки в превью."""
from pathlib import Path

from PIL import Image

GEN = Path("/home/z/my-project/scripts/gen")
OUT = Path("/home/z/my-project/public/img")
OUT.mkdir(parents=True, exist_ok=True)

# (имя, макс. ширина, качество webp)
JOBS = [
    ("hero", 1024, 78),
    ("pack-missions", 560, 74),
    ("pack-combat", 560, 74),
    ("pack-driving", 560, 74),
    ("pack-police", 560, 74),
    ("pack-money", 560, 74),
    ("pack-street", 560, 74),
]

total = 0
for name, width, quality in JOBS:
    src = GEN / f"{name}.png"
    dst = OUT / f"{name}.webp"
    if not src.exists():
        print(f"MISS {name}")
        continue
    img = Image.open(src).convert("RGB")
    if img.width > width:
        ratio = width / img.width
        img = img.resize((width, round(img.height * ratio)), Image.LANCZOS)
    img.save(dst, "WEBP", quality=quality, method=6)
    kb = dst.stat().st_size / 1024
    total += kb
    print(f"OK {name}: {img.width}x{img.height} -> {kb:.0f} KB")

print(f"TOTAL: {total:.0f} KB")
