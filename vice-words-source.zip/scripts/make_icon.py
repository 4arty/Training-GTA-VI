"""Генерация иконки 640x360 PNG для Telegram Mini App (BotFather)."""
from PIL import Image

SRC = "/home/z/my-project/public/img/hero.webp"
OUT_PUBLIC = "/home/z/my-project/public/icon-telegram.png"
OUT_DL = "/home/z/my-project/download/vice-words-telegram-icon.png"
SIZE = (640, 360)
BG = (10, 5, 20)  # тёмный фон в стиле Vice City

img = Image.open(SRC).convert("RGBA")
w, h = img.size
print(f"source: {w}x{h}")

# cover-кроп до 16:9, затем ресайз до 640x360
target_ratio = SIZE[0] / SIZE[1]
ratio = w / h
if ratio > target_ratio:  # источник шире — режем бока
    new_w = int(h * target_ratio)
    x0 = (w - new_w) // 2
    img = img.crop((x0, 0, x0 + new_w, h))
else:  # источник выше — режем верх/низ
    new_h = int(w / target_ratio)
    y0 = (h - new_h) // 2
    img = img.crop((0, y0, w, y0 + new_h))

canvas = Image.new("RGB", SIZE, BG)
canvas.paste(img.resize(SIZE, Image.LANCZOS), (0, 0))
canvas.save(OUT_PUBLIC, "PNG", optimize=True)
canvas.save(OUT_DL, "PNG", optimize=True)
print("saved:", OUT_PUBLIC, OUT_DL, canvas.size)
