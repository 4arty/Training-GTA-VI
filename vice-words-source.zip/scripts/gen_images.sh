#!/bin/bash
# Генерация арта для VICE WORDS в едином стиле: retro synthwave / Vice City
set -u
GEN=/home/z/my-project/scripts/gen
mkdir -p "$GEN"

STYLE="1980s retro synthwave poster illustration, vice city miami aesthetic, dark purple night background, neon glow lighting, vibrant pink teal orange palette, grainy retro print texture, cinematic composition, absolutely no text no letters no watermark, high quality, detailed"

declare -A JOBS
JOBS[hero]="retrowave city skyline at dusk with palm tree silhouettes and ocean, retro sun with horizontal scanlines on the horizon, art deco hotels lit with neon, sports car silhouette on the promenade, wide panoramic view"
JOBS[pack-missions]="a glowing neon pink city map on a dark table with location pins, polaroid photos and a dossier folder, detective mission planning scene"
JOBS[pack-combat]="a large glowing crosshair reticle hovering over a dark city street at night, light streaks and sparks, intense orange red neon glow, abstract action scene, no weapons, no people"
JOBS[pack-driving]="a retro sports car speeding along an ocean drive boulevard at sunset, palm trees, long motion blur light trails, outrun racing mood"
JOBS[pack-police]="a police car with flashing teal and blue lights on a rainy night street, reflections on wet asphalt, cinematic noir mood, no people close-up"
JOBS[pack-money]="stacks of banknotes and gold coins with a duffel bag on a dark table, golden neon glow, luxurious heist loot mood"
JOBS[pack-street]="two silhouettes chatting on a neon lit street corner, glowing speech bubble neon signs on a graffiti wall, purple neon mood"

for key in hero pack-missions pack-combat pack-driving pack-police pack-money pack-street; do
  size="1024x1024"
  [ "$key" = "hero" ] && size="1440x720"
  out="$GEN/$key.png"
  if [ -s "$out" ]; then echo "SKIP $key (exists)"; continue; fi
  echo "=== generating $key ($size) ==="
  z-ai image -p "${JOBS[$key]}, $STYLE" -o "$out" -s "$size" || echo "FAILED $key"
done
echo "=== DONE ==="
ls -la "$GEN"
