"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Backdrop } from "@/components/gta/Backdrop";
import { BootScreen } from "@/components/gta/BootScreen";
import { NavBar, type Tab } from "@/components/gta/NavBar";
import { HomeScreen } from "@/components/gta/HomeScreen";
import { PackScreen } from "@/components/gta/PackScreen";
import { FlashcardSession } from "@/components/gta/FlashcardSession";
import { QuizSession } from "@/components/gta/QuizSession";
import { DictionaryScreen } from "@/components/gta/DictionaryScreen";
import { ProfileScreen } from "@/components/gta/ProfileScreen";
import { initTelegram, tg } from "@/lib/telegram";
import { setSoundEnabled } from "@/lib/sfx";
import { useProgress } from "@/lib/store";
import type { PackId } from "@/lib/words";

type View =
  | { name: "home" }
  | { name: "dict" }
  | { name: "profile" }
  | { name: "pack"; packId: PackId }
  | { name: "cards"; packId: PackId }
  | { name: "quiz"; packId: PackId | "all"; count: number };

export default function Page() {
  const [booted, setBooted] = useState(false);
  const [view, setView] = useState<View>({ name: "home" });

  const sound = useProgress((s) => s.sound);

  // Telegram init
  useEffect(() => {
    initTelegram();
  }, []);

  // Синхронизация звука
  useEffect(() => {
    setSoundEnabled(sound);
  }, [sound]);

  // Telegram BackButton
  const backHandler = useRef<() => void>(() => {});
  useEffect(() => {
    const t = tg();
    if (!t?.BackButton) return;
    const cb = () => backHandler.current();
    t.BackButton.onClick(cb);
    return () => {
      try {
        t.BackButton?.offClick(cb);
      } catch {
        /* ignore */
      }
    };
  }, []);

  useEffect(() => {
    const t = tg();
    if (!t?.BackButton) return;
    const isRoot = view.name === "home" || view.name === "dict" || view.name === "profile";
    if (isRoot) {
      t.BackButton.hide();
      return;
    }
    backHandler.current = () => {
      if (view.name === "pack") setView({ name: "home" });
      else if (view.name === "cards" || view.name === "quiz") setView({ name: "pack", packId: view.packId === "all" ? "missions" : (view.packId as PackId) });
    };
    t.BackButton.show();
  }, [view]);

  const openPack = (packId: PackId) => setView({ name: "pack", packId });
  const startMixed = () => setView({ name: "quiz", packId: "all", count: 12 });

  const sessionView = view.name === "cards" || view.name === "quiz";

  return (
    <>
      {!booted && <BootScreen onDone={() => setBooted(true)} />}

      <Backdrop />

      <main
        className={`relative mx-auto w-full max-w-lg px-4 pt-6 transition-opacity duration-300 ${
          sessionView ? "pb-4" : "pb-28"
        } ${booted ? "opacity-100" : "pointer-events-none opacity-0"}`}
      >
        <AnimatePresence mode="wait">
          {view.name === "home" && (
            <motion.div key="home" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.18 }}>
              <HomeScreen onOpenPack={openPack} onStartMixed={startMixed} />
            </motion.div>
          )}
          {view.name === "dict" && (
            <motion.div key="dict" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.18 }}>
              <DictionaryScreen />
            </motion.div>
          )}
          {view.name === "profile" && (
            <motion.div key="profile" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.18 }}>
              <ProfileScreen />
            </motion.div>
          )}
          {view.name === "pack" && (
            <motion.div key={`pack-${view.packId}`} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.18 }}>
              <PackScreen
                packId={view.packId}
                onBack={() => setView({ name: "home" })}
                onStartCards={() => setView({ name: "cards", packId: view.packId })}
                onStartQuiz={() => setView({ name: "quiz", packId: view.packId, count: 10 })}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {!sessionView && (
          <NavBar
            active={view.name === "pack" ? "home" : (view.name as Tab)}
            onChange={(t) => setView({ name: t } as View)}
          />
        )}
      </main>

      {/* Полноэкранные сессии */}
      {view.name === "cards" && <FlashcardSession key={`cards-${view.packId}`} packId={view.packId} onExit={() => setView({ name: "pack", packId: view.packId })} />}
      {view.name === "quiz" && (
        <QuizSession key={`quiz-${view.packId}-${view.count}`} packId={view.packId} count={view.count} onExit={() => (view.packId === "all" ? setView({ name: "home" }) : setView({ name: "pack", packId: view.packId }))} />
      )}

    </>
  );
}