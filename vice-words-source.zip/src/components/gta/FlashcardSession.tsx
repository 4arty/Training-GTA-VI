"use client";

import { useMemo, useRef, useState } from "react";
import { Check, RotateCcw, Volume2, X, Zap } from "lucide-react";
import { getPack, wordsOf, type PackId } from "@/lib/words";
import { useProgress } from "@/lib/store";
import { sfx, speakWord } from "@/lib/sfx";
import { hapticLight, hapticNotify } from "@/lib/telegram";

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

interface Props {
  packId: PackId;
  onExit: () => void;
}

export function FlashcardSession({ packId, onExit }: Props) {
  const pack = getPack(packId);
  const recordAnswer = useProgress((s) => s.recordAnswer);
  const markSeen = useProgress((s) => s.markSeen);
  const xpNow = useProgress((s) => s.xp);

  const queueInit = useRef<string[] | null>(null);
  if (queueInit.current === null) {
    // сначала самые «слабые» слова
    const st = useProgress.getState().stats;
    const sorted = [...wordsOf(packId)].sort((a, b) => {
      const sa = st[a.id]?.streak ?? 0;
      const sb = st[b.id]?.streak ?? 0;
      return sa - sb;
    });
    queueInit.current = shuffle(sorted).map((w) => w.id);
  }

  const [queue, setQueue] = useState<string[]>(queueInit.current);
  const [flipped, setFlipped] = useState(false);
  const [known, setKnown] = useState(0);
  const xpStart = useRef<number | null>(null);
  if (xpStart.current === null) xpStart.current = xpNow;

  const words = useMemo(() => wordsOf(packId), [packId]);
  const total = words.length;
  const current = queue.length > 0 ? words.find((w) => w.id === queue[0]) ?? words[0] : null;
  const done = queue.length === 0;
  const gained = xpNow - (xpStart.current ?? 0);

  const onKnow = () => {
    if (!current) return;
    sfx.know();
    hapticNotify(true);
    recordAnswer(current.id, true, 4);
    setKnown((k) => k + 1);
    setFlipped(false);
    setQueue((q) => q.slice(1));
  };

  const onRepeat = () => {
    if (!current) return;
    sfx.flip();
    hapticLight();
    markSeen(current.id);
    setFlipped(false);
    setQueue((q) => (q.length > 1 ? [...q.slice(1), q[0]] : q));
  };

  return (
    <div className="fixed inset-0 z-40 overflow-y-auto vw-scroll bg-[#0b0217]/97 backdrop-blur-md">
      <div className="mx-auto flex min-h-dvh w-full max-w-lg flex-col px-4 pb-8 pt-5">
        {/* Шапка */}
        <div className="flex items-center justify-between">
          <button
            onClick={onExit}
            className="flex h-9 w-9 items-center justify-center rounded-xl glass transition-colors hover:bg-white/10"
            aria-label="Выйти из тренировки"
          >
            <X className="h-4 w-4" />
          </button>
          <div className="text-center">
            <p className="text-[10px] uppercase tracking-[0.25em]" style={{ color: pack.color }}>
              {pack.title}
            </p>
            <p className="text-xs text-white/50">осталось {queue.length}</p>
          </div>
          <div className="flex h-9 items-center gap-1 rounded-xl glass px-2.5 text-xs font-display">
            <Zap className="h-3.5 w-3.5 text-[#ffc233]" /> +{gained}
          </div>
        </div>

        {/* Прогресс */}
        <div className="mt-4 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
          <div
            className="h-full rounded-full transition-[width] duration-300"
            style={{ width: `${((total - queue.length) / total) * 100}%`, background: `linear-gradient(90deg, ${pack.color}, #ffc233)` }}
          />
        </div>

        {done ? (
          // ─── Итог тренировки ───
          <div className="flex flex-1 flex-col items-center justify-center text-center anim-pop">
            <div className="mb-5 flex h-20 w-20 items-center justify-center rounded-full" style={{ background: "rgba(33,230,193,0.12)", boxShadow: "0 0 40px -10px #21e6c1" }}>
              <Check className="h-10 w-10 text-[#21e6c1]" />
            </div>
            <h2 className="font-display text-3xl text-teal-neon">ЗАЧИСТКА ЗАВЕРШЕНА</h2>
            <p className="mt-2 text-sm text-white/55">
              Ты проверил все слова района «{pack.titleRu}»
            </p>
            <div className="mt-6 grid w-full max-w-xs grid-cols-2 gap-3">
              <div className="glass rounded-2xl p-4">
                <p className="font-display text-2xl text-[#21e6c1]">{known}</p>
                <p className="text-[11px] text-white/50">знаю</p>
              </div>
              <div className="glass rounded-2xl p-4">
                <p className="font-display text-2xl text-[#ffc233]">+{gained}</p>
                <p className="text-[11px] text-white/50">XP</p>
              </div>
            </div>
            <button
              onClick={onExit}
              className="neon-glow-pink mt-8 w-full max-w-xs rounded-2xl px-4 py-3.5 font-bold"
              style={{ background: "linear-gradient(135deg,#ff2e7e,#ff8a1e)", color: "#1a0512" }}
            >
              Готово
            </button>
          </div>
        ) : (
          current && (
            <>
              {/* Карточка */}
              <div className="flex flex-1 items-center py-6">
                <div className="flip-scene w-full">
                  <button
                    onClick={() => {
                      sfx.flip();
                      hapticLight();
                      setFlipped((f) => !f);
                    }}
                    className={`flip-inner relative block h-[340px] w-full text-left ${flipped ? "flipped" : ""}`}
                    aria-label="Перевернуть карточку"
                  >
                    {/* Лицевая сторона — слово */}
                    <div
                      className="flip-face absolute inset-0 flex flex-col items-center justify-center rounded-3xl p-6"
                      style={{
                        background: "rgba(255,255,255,0.045)",
                        border: `1px solid ${pack.color}55`,
                        boxShadow: `0 0 44px -14px ${pack.color}`,
                      }}
                    >
                      <p className="text-[10px] uppercase tracking-[0.3em] text-white/40">английский</p>
                      <p className="mt-4 text-center font-display text-4xl leading-tight text-white">{current.en}</p>
                      <p className="mt-3 text-sm text-white/50">{current.ipa}</p>
                      <span
                        onClick={(e) => {
                          e.stopPropagation();
                          speakWord(current.en);
                          hapticLight();
                        }}
                        className="mt-6 flex h-11 w-11 items-center justify-center rounded-xl transition-colors hover:bg-white/10"
                        role="button"
                        aria-label={`Озвучить ${current.en}`}
                      >
                        <Volume2 className="h-5 w-5 text-[#21e6c1]" />
                      </span>
                      <p className="absolute bottom-5 text-[10px] text-white/35">нажми, чтобы перевернуть</p>
                    </div>

                    {/* Обратная сторона — перевод и пример */}
                    <div
                      className="flip-face back absolute inset-0 flex flex-col items-center justify-center rounded-3xl p-6"
                      style={{
                        background: "rgba(255,255,255,0.045)",
                        border: "1px solid rgba(33,230,193,0.4)",
                        boxShadow: "0 0 44px -14px #21e6c1",
                      }}
                    >
                      <p className="text-[10px] uppercase tracking-[0.3em] text-white/40">перевод</p>
                      <p className="mt-4 text-center text-2xl font-bold leading-snug text-[#3effd0]">{current.ru}</p>
                      <p className="mt-6 text-center text-sm italic text-[#ffc233]/90">«{current.ex}»</p>
                      <p className="mt-2 text-center text-xs text-white/55">{current.exRu}</p>
                    </div>
                  </button>
                </div>
              </div>

              {/* Кнопки */}
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={onRepeat}
                  className="glass flex items-center justify-center gap-2 rounded-2xl px-4 py-3.5 text-sm font-semibold text-white/80 transition-colors hover:bg-white/10"
                >
                  <RotateCcw className="h-4 w-4" /> Повторю
                </button>
                <button
                  onClick={onKnow}
                  className="flex items-center justify-center gap-2 rounded-2xl px-4 py-3.5 text-sm font-bold transition-transform active:scale-95"
                  style={{ background: "linear-gradient(135deg,#21e6c1,#3effd0)", color: "#062a22" }}
                >
                  <Check className="h-4 w-4" /> Знаю · +4 XP
                </button>
              </div>
            </>
          )
        )}
      </div>
    </div>
  );
}
