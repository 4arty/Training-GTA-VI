"use client";

import { BookOpen, House, UserRound } from "lucide-react";
import { hapticLight } from "@/lib/telegram";
import { sfx } from "@/lib/sfx";

export type Tab = "home" | "dict" | "profile";

interface Props {
  active: Tab;
  onChange: (t: Tab) => void;
}

export function NavBar({ active, onChange }: Props) {
  const tabs: { id: Tab; label: string; icon: typeof House }[] = [
    { id: "home", label: "База", icon: House },
    { id: "dict", label: "Словарь", icon: BookOpen },
    { id: "profile", label: "Дело", icon: UserRound },
  ];

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-30 border-t border-white/10"
      style={{
        background: "rgba(11,2,23,0.85)",
        backdropFilter: "blur(14px)",
        paddingBottom: "max(env(safe-area-inset-bottom), 6px)",
      }}
    >
      <div className="mx-auto flex w-full max-w-lg items-stretch justify-around px-2 py-1.5">
        {tabs.map((t) => {
          const Icon = t.icon;
          const isActive = active === t.id;
          return (
            <button
              key={t.id}
              onClick={() => {
                if (!isActive) {
                  sfx.tap();
                  hapticLight();
                  onChange(t.id);
                }
              }}
              className="relative flex min-w-[64px] flex-col items-center gap-0.5 px-3 py-2 transition-colors"
              aria-label={t.label}
              aria-current={isActive ? "page" : undefined}
            >
              {isActive && (
                <span
                  className="absolute -top-[7px] h-1 w-8 rounded-full"
                  style={{ background: "linear-gradient(90deg,#ff2e7e,#ff8a1e)", boxShadow: "0 0 12px rgba(255,46,126,0.8)" }}
                />
              )}
              <Icon className="h-5 w-5 transition-colors" style={{ color: isActive ? "#ff5fa8" : "rgba(255,255,255,0.4)" }} />
              <span
                className="text-[10px] font-semibold transition-colors"
                style={{ color: isActive ? "#ff5fa8" : "rgba(255,255,255,0.4)" }}
              >
                {t.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
