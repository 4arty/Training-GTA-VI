"use client";

import { useMemo, useState } from "react";
import { Search, Volume2 } from "lucide-react";
import { ALL_WORDS, PACKS, type PackId } from "@/lib/words";
import { isMastered, useProgress } from "@/lib/store";
import { speakWord } from "@/lib/sfx";
import { hapticLight } from "@/lib/telegram";

type StatusFilter = "all" | "new" | "learning" | "mastered";

export function DictionaryScreen() {
  const stats = useProgress((s) => s.stats);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<StatusFilter>("all");
  const [pack, setPack] = useState<PackId | "all">("all");

  const list = useMemo(() => {
    return ALL_WORDS.filter((w) => {
      if (pack !== "all" && w.pack !== pack) return false;
      const st = stats[w.id];
      if (status === "mastered" && !isMastered(st)) return false;
      if (status === "new" && (st?.seen ?? 0) > 0) return false;
      if (status === "learning" && ((st?.seen ?? 0) === 0 || isMastered(st))) return false;
      const query = q.trim().toLowerCase();
      if (query && !w.en.toLowerCase().includes(query) && !w.ru.toLowerCase().includes(query) && !w.ex.toLowerCase().includes(query)) return false;
      return true;
    });
  }, [q, status, pack, stats]);

  const statusChip = (id: StatusFilter, label: string) => (
    <button
      key={id}
      onClick={() => hapticLight() || setStatus(id)}
      className="rounded-full px-3.5 py-1.5 text-xs font-semibold transition-colors"
      style={
        status === id
          ? { background: "rgba(255,46,126,0.18)", color: "#ff5fa8", border: "1px solid rgba(255,46,126,0.45)" }
          : { background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.55)", border: "1px solid rgba(255,255,255,0.09)" }
      }
    >
      {label}
    </button>
  );

  return (
    <div className="space-y-4 anim-rise">
      <h1 className="font-display text-2xl tracking-wide">
        СЛОВАРЬ <span className="text-vice">LEONIDA</span>
      </h1>

      <div className="relative">
        <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-white/35" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Слово, перевод или пример…"
          className="glass w-full rounded-2xl py-3 pl-10 pr-4 text-sm outline-none transition-colors placeholder:text-white/35 focus:border-[#ff2e7e]/60"
        />
      </div>

      <div className="flex flex-wrap gap-2">
        {statusChip("all", "Все")}
        {statusChip("new", "Новые")}
        {statusChip("learning", "В процессе")}
        {statusChip("mastered", "Выучено")}
      </div>

      <div className="flex flex-wrap gap-1.5">
        <button
          onClick={() => setPack("all")}
          className="rounded-full px-3 py-1 text-[11px] font-semibold transition-colors"
          style={
            pack === "all"
              ? { background: "rgba(33,230,193,0.14)", color: "#3effd0", border: "1px solid rgba(33,230,193,0.4)" }
              : { background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.5)", border: "1px solid rgba(255,255,255,0.09)" }
          }
        >
          Все районы
        </button>
        {PACKS.map((p) => (
          <button
            key={p.id}
            onClick={() => setPack(p.id)}
            className="rounded-full px-3 py-1 text-[11px] font-semibold transition-colors"
            style={
              pack === p.id
                ? { background: `${p.color}22`, color: p.color, border: `1px solid ${p.color}66` }
                : { background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.5)", border: "1px solid rgba(255,255,255,0.09)" }
            }
          >
            {p.titleRu}
          </button>
        ))}
      </div>

      <p className="text-[11px] text-white/40">Найдено: {list.length}</p>

      <div className="space-y-1.5 pb-2">
        {list.map((w) => {
          const st = stats[w.id];
          const m = isMastered(st);
          const seen = (st?.seen ?? 0) > 0;
          return (
            <div key={w.id} className="glass rounded-xl px-4 py-3">
              <div className="flex items-center gap-3">
                <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: m ? "#21e6c1" : seen ? "#ff8a1e" : "rgba(255,255,255,0.25)" }} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline gap-2">
                    <span className="truncate text-sm font-semibold">{w.en}</span>
                    <span className="shrink-0 text-[10px] text-white/35">{w.ipa}</span>
                  </div>
                  <p className="truncate text-xs text-white/55">{w.ru}</p>
                </div>
                <button
                  onClick={() => {
                    speakWord(w.en);
                    hapticLight();
                  }}
                  className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg transition-colors hover:bg-white/10"
                  aria-label={`Озвучить ${w.en}`}
                >
                  <Volume2 className="h-4 w-4 text-white/50" />
                </button>
              </div>
              <p className="mt-2 pl-5 text-[11px] italic text-[#ffc233]/75">«{w.ex}»</p>
              <p className="mt-0.5 pl-5 text-[11px] text-white/45">{w.exRu}</p>
            </div>
          );
        })}
        {list.length === 0 && (
          <div className="glass rounded-2xl p-8 text-center text-sm text-white/50">Ничего не найдено. Попробуй другой запрос.</div>
        )}
      </div>
    </div>
  );
}
