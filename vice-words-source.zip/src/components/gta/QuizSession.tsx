"use client";

import { useMemo, useRef, useState } from "react";
import { Heart, RotateCcw, Star, Volume2, X, Zap } from "lucide-react";
import { ALL_WORDS, getPack, wordsOf, type PackId } from "@/lib/words";
import { useProgress } from "@/lib/store";
import { sfx, speakWord } from "@/lib/sfx";
import { hapticLight, hapticNotify } from "@/lib/telegram";

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

interface Props {
  packId: PackId | "all";
  count: number;
  onExit: () => void;
}

interface Q {
  id: string;
  en: string;
  ipa: string;
  ru: string;
  pack: PackId;
  options: string[];
}

export function QuizSession({ packId, count, onExit }: Props) {
  const [attempt, setAttempt] = useState(0);
  const recordAnswer = useProgress((s) => s.recordAnswer);
  const finishRun = useProgress((s) => s.finishRun);
  const xpNow = useProgress((s) => s.xp);
  const xpStart = useRef<number | null>(null);
  if (xpStart.current === null) xpStart.current = xpNow;
  const gained = xpNow - xpStart.current;

  const questions = useMemo<Q[]>(() => {
    const pool = packId === "all" ? ALL_WORDS : wordsOf(packId);
    const st = useProgress.getState().stats;
    // сначала самые слабые слова, затем перемешиваем порядок вопросов
    const sorted = [...pool].sort((a, b) => {
      const sa = st[a.id]?.streak ?? 0;
      const sb = st[b.id]?.streak ?? 0;
      if (sa !== sb) return sa - sb;
      return Math.random() - 0.5;
    });
    const picked = shuffle(sorted.slice(0, count));
    return picked.map((w) => {
      const distractors = shuffle(ALL_WORDS.filter((x) => x.ru !== w.ru))
        .slice(0, 3)
        .map((x) => x.ru);
      return {
        id: w.id,
        en: w.en,
        ipa: w.ipa,
        ru: w.ru,
        pack: w.pack,
        options: shuffle([w.ru, ...distractors]),
      };
    });
  }, [packId, count, attempt]);

  const [idx, setIdx] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [lives, setLives] = useState(3);
  const [correctCount, setCorrectCount] = useState(0);
  const [phase, setPhase] = useState<"play" | "passed" | "wasted">("play");
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const q = questions[idx];
  const perfect = correctCount === questions.length;
  const accuracy = questions.length > 0 ? correctCount / questions.length : 0;
  const stars = accuracy >= 0.9 ? 3 : accuracy >= 0.7 ? 2 : 1;

  const onAnswer = (ru: string) => {
    if (selected || !q) return;
    const ok = ru === q.ru;
    setSelected(ru);
    recordAnswer(q.id, ok);
    if (ok) {
      sfx.correct();
      hapticNotify(true);
      setCorrectCount((c) => c + 1);
    } else {
      sfx.wrong();
      hapticNotify(false);
      setLives((l) => l - 1);
    }
    timer.current = setTimeout(() => {
      setSelected(null);
      if (!ok && lives - 1 <= 0) {
        sfx.wasted();
        setPhase("wasted");
        return;
      }
      if (idx + 1 >= questions.length) {
        const finalCorrect = ok ? correctCount + 1 : correctCount;
        const acc = finalCorrect / questions.length;
        const bonus = acc === 1 ? 25 : acc >= 0.7 ? 15 : 8;
        finishRun(acc === 1, bonus);
        sfx.pass();
        setPhase("passed");
        return;
      }
      setIdx((i) => i + 1);
    }, 1150);
  };

  const restart = () => {
    if (timer.current) clearTimeout(timer.current);
    xpStart.current = useProgress.getState().xp;
    setIdx(0);
    setSelected(null);
    setLives(3);
    setCorrectCount(0);
    setPhase("play");
    setAttempt((a) => a + 1);
  };

  const packOfQ = q ? getPack(q.pack) : null;

  return (
    <div className="fixed inset-0 z-40 overflow-y-auto vw-scroll bg-[#0b0217]/97 backdrop-blur-md">
      <div className="mx-auto flex min-h-dvh w-full max-w-lg flex-col px-4 pb-8 pt-5">
        {/* Шапка */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => {
              if (timer.current) clearTimeout(timer.current);
              onExit();
            }}
            className="flex h-9 w-9 items-center justify-center rounded-xl glass transition-colors hover:bg-white/10"
            aria-label="Выйти из квиза"
          >
            <X className="h-4 w-4" />
          </button>
          <div className="flex items-center gap-1.5">
            {[0, 1, 2].map((i) => (
              <Heart
                key={i}
                className="h-5 w-5 transition-colors"
                style={{
                  fill: i < lives ? "#ff2e7e" : "transparent",
                  color: i < lives ? "#ff2e7e" : "rgba(255,255,255,0.2)",
                }}
              />
            ))}
          </div>
          <div className="flex h-9 items-center gap-1 rounded-xl glass px-2.5 text-xs font-display">
            <Zap className="h-3.5 w-3.5 text-[#ffc233]" /> +{gained}
          </div>
        </div>

        {/* Прогресс */}
        <div className="mt-4 flex items-center gap-2">
          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/10">
            <div
              className="h-full rounded-full transition-[width] duration-300"
              style={{ width: `${(idx / Math.max(1, questions.length)) * 100}%`, background: "linear-gradient(90deg,#ff2e7e,#ffc233)" }}
            />
          </div>
          <span className="text-[11px] text-white/50 font-display shrink-0">
            {Math.min(idx + 1, questions.length)}/{questions.length}
          </span>
        </div>

        {phase === "play" && q && (
          <div className="flex flex-1 flex-col justify-center gap-6 py-6">
            <div className="text-center anim-pop" key={q.id}>
              {packOfQ && (
                <span
                  className="mb-4 inline-block rounded-full px-3 py-1 text-[10px] uppercase tracking-[0.2em]"
                  style={{ background: `${packOfQ.color}1c`, color: packOfQ.color }}
                >
                  {packOfQ.titleRu}
                </span>
              )}
              <h2 className="font-display text-4xl leading-tight">{q.en}</h2>
              <p className="mt-2 text-sm text-white/45">{q.ipa}</p>
              <button
                onClick={() => {
                  speakWord(q.en);
                  hapticLight();
                }}
                className="mx-auto mt-4 flex h-10 w-10 items-center justify-center rounded-xl glass transition-colors hover:bg-white/10"
                aria-label={`Озвучить ${q.en}`}
              >
                <Volume2 className="h-4.5 w-4.5 text-[#21e6c1]" />
              </button>
            </div>

            <div className="space-y-2.5">
              {q.options.map((ru, i) => {
                const isCorrect = ru === q.ru;
                const isPicked = selected === ru;
                const reveal = selected !== null;
                let cls = "glass hover:border-white/25 transition-colors text-left";
                if (reveal && isCorrect) cls = "text-left border-[#21e6c1] bg-[#21e6c1]/12 anim-pop";
                else if (reveal && isPicked && !isCorrect) cls = "text-left border-[#ff3b5c] bg-[#ff3b5c]/10 anim-shake";
                else if (reveal) cls = "text-left glass opacity-45";
                return (
                  <button
                    key={ru}
                    onClick={() => onAnswer(ru)}
                    disabled={reveal}
                    className={`flex w-full items-center gap-3 rounded-2xl border px-4 py-3.5 text-sm ${cls}`}
                    style={{ borderStyle: "solid", borderWidth: 1 }}
                  >
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-white/8 font-display text-xs text-white/60">
                      {String.fromCharCode(65 + i)}
                    </span>
                    <span className="flex-1">{ru}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* ─── MISSION PASSED ─── */}
        {phase === "passed" && (
          <div className="flex flex-1 flex-col items-center justify-center text-center anim-pop">
            <div className="anim-stamp">
              <h2 className="font-display text-4xl text-vice">MISSION PASSED!</h2>
            </div>
            <div className="mt-4 flex gap-1.5">
              {[0, 1, 2].map((i) => (
                <Star
                  key={i}
                  className="h-8 w-8 transition-all"
                  style={{
                    fill: i < stars ? "#ffc233" : "transparent",
                    color: i < stars ? "#ffc233" : "rgba(255,255,255,0.2)",
                    filter: i < stars ? "drop-shadow(0 0 10px rgba(255,194,51,0.7))" : undefined,
                  }}
                />
              ))}
            </div>
            <p className="mt-3 text-sm text-white/55">
              {perfect ? "Идеально. Как настоящее ограбление." : stars === 2 ? "Хорошая работа, но есть куда расти." : "Дело закрыто, но не идеально."}
            </p>
            <div className="mt-6 grid w-full max-w-xs grid-cols-3 gap-2.5">
              <div className="glass rounded-2xl p-3">
                <p className="font-display text-xl text-[#21e6c1]">{correctCount}</p>
                <p className="text-[10px] text-white/50">верных</p>
              </div>
              <div className="glass rounded-2xl p-3">
                <p className="font-display text-xl text-[#ff8a1e]">{Math.round(accuracy * 100)}%</p>
                <p className="text-[10px] text-white/50">точность</p>
              </div>
              <div className="glass rounded-2xl p-3">
                <p className="font-display text-xl text-[#ffc233]">+{gained}</p>
                <p className="text-[10px] text-white/50">XP</p>
              </div>
            </div>
            <div className="mt-8 grid w-full max-w-xs grid-cols-2 gap-3">
              <button onClick={restart} className="glass flex items-center justify-center gap-2 rounded-2xl px-4 py-3.5 text-sm font-semibold transition-colors hover:bg-white/10">
                <RotateCcw className="h-4 w-4" /> Ещё раз
              </button>
              <button
                onClick={onExit}
                className="neon-glow-pink rounded-2xl px-4 py-3.5 text-sm font-bold"
                style={{ background: "linear-gradient(135deg,#ff2e7e,#ff8a1e)", color: "#1a0512" }}
              >
                Продолжить
              </button>
            </div>
          </div>
        )}

        {/* ─── WASTED ─── */}
        {phase === "wasted" && (
          <div className="flex flex-1 flex-col items-center justify-center text-center">
            <div className="anim-stamp">
              <h2 className="font-display text-6xl text-[#ff3b5c]" style={{ textShadow: "0 0 30px rgba(255,59,92,0.6)" }}>
                WASTED
              </h2>
            </div>
            <p className="mt-4 text-sm text-white/55">Три жизни потеряны. Но каждый труп в Вайс-Сити — опыт.</p>
            <div className="mt-6 grid w-full max-w-xs grid-cols-2 gap-2.5">
              <div className="glass rounded-2xl p-3.5">
                <p className="font-display text-xl text-[#21e6c1]">{correctCount}</p>
                <p className="text-[10px] text-white/50">верных до провала</p>
              </div>
              <div className="glass rounded-2xl p-3.5">
                <p className="font-display text-xl text-[#ffc233]">+{gained}</p>
                <p className="text-[10px] text-white/50">XP всё равно твой</p>
              </div>
            </div>
            <div className="mt-8 grid w-full max-w-xs grid-cols-2 gap-3">
              <button
                onClick={restart}
                className="flex items-center justify-center gap-2 rounded-2xl px-4 py-3.5 text-sm font-bold"
                style={{ background: "linear-gradient(135deg,#ff2e7e,#ff8a1e)", color: "#1a0512" }}
              >
                <RotateCcw className="h-4 w-4" /> Реинкарнация
              </button>
              <button onClick={onExit} className="glass rounded-2xl px-4 py-3.5 text-sm font-semibold transition-colors hover:bg-white/10">
                Выйти
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
