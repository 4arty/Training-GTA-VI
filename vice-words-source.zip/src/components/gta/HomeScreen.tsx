"use client";

import { motion } from "framer-motion";
import { Banknote, CarFront, ChevronRight, Crosshair, Flame, MessagesSquare, Play, Siren, Target, Zap } from "lucide-react";
import { PACKS, wordsOf, type Pack, type PackId } from "@/lib/words";
import { getRank, isMastered, useProgress } from "@/lib/store";
import { tgUserName } from "@/lib/telegram";
import { sfx } from "@/lib/sfx";

const ICONS = {
  target: Target,
  crosshair: Crosshair,
  car: CarFront,
  siren: Siren,
  banknote: Banknote,
  chat: MessagesSquare,
} as const;

interface Props {
  onOpenPack: (id: PackId) => void;
  onStartMixed: () => void;
}

export function HomeScreen({ onOpenPack, onStartMixed }: Props) {
  const xp = useProgress((s) => s.xp);
  const stats = useProgress((s) => s.stats);
  const todayXP = useProgress((s) => s.todayXP);
  const dailyGoal = useProgress((s) => s.dailyGoal);
  const goalDays = useProgress((s) => s.goalDays);

  const rank = getRank(xp);
  const streak = calcStreakSafe(goalDays);
  const name = tgUserName();

  const masteredTotal = PACKS.reduce((acc, p) => acc + wordsOf(p.id).filter((w) => isMastered(stats[w.id])).length, 0);
  const totalWords = PACKS.reduce((acc, p) => acc + wordsOf(p.id).length, 0);

  return (
    <div className="space-y-5">
      {/* Ранг + стрик */}
      <div className="flex items-center justify-between gap-3">
        <div className="glass rounded-2xl px-4 py-2.5 flex-1 min-w-0">
          <p className="text-[10px] uppercase tracking-[0.2em] text-white/45">Ранг {rank.index}</p>
          <p className="font-display text-base leading-tight truncate">{rank.title}</p>
          <div className="mt-1.5 h-1 w-full overflow-hidden rounded-full bg-white/10">
            <div
              className="h-full rounded-full"
              style={{ width: `${Math.round(rank.progress * 100)}%`, background: "linear-gradient(90deg,#ff2e7e,#ff8a1e)" }}
            />
          </div>
          <p className="mt-1 text-[10px] text-white/40">
            {rank.nextTitle ? `${xp} / ${rank.nextMin} XP до «${rank.nextTitle}»` : "Максимальный ранг достигнут"}
          </p>
        </div>
        <div className="glass rounded-2xl px-4 py-2.5 flex flex-col items-center min-w-[76px]">
          <Flame className="h-5 w-5 text-[#ff8a1e]" />
          <p className="font-display text-xl leading-tight mt-0.5">{streak}</p>
          <p className="text-[10px] text-white/45">дней подряд</p>
        </div>
      </div>

      {/* Логотип */}
      <div className="text-center pt-1">
        <h1 className="font-display text-4xl tracking-wide anim-flicker">
          <span className="text-vice">VICE</span> <span className="text-teal-neon">WORDS</span>
        </h1>
        <p className="mt-1 text-xs text-white/55">
          {name ? `${name}, выучь слова — пройди GTA VI без субтитров` : "Выучь слова — пройди GTA VI без субтитров"}
        </p>
      </div>

      {/* Баннер города */}
      <div className="relative overflow-hidden rounded-2xl border border-white/10 anim-rise">
        <img
          src="/img/hero.webp"
          alt="Неоновый Вайс-Сити"
          className="block aspect-[16/9] w-full object-cover"
        />
        <div
          className="pointer-events-none absolute inset-0"
          style={{ background: "linear-gradient(180deg, rgba(11,2,23,0.12) 0%, rgba(11,2,23,0.28) 45%, rgba(11,2,23,0.88) 100%)" }}
        />
        <div className="absolute bottom-3 left-4 right-4">
          <p className="font-display text-[10px] tracking-[0.35em] text-[#21e6c1] anim-flicker">LEONIDA · VICE CITY</p>
          <p className="mt-0.5 text-[11px] text-white/80">Неоновые улицы ждут. Слова — твой пропуск в игру.</p>
        </div>
      </div>

      {/* Дневная цель */}
      <div className="glass rounded-2xl p-4 flex items-center gap-4">
        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl" style={{ background: "rgba(33,230,193,0.12)" }}>
          <Zap className="h-5 w-5 text-[#21e6c1]" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-baseline justify-between">
            <p className="text-sm font-semibold">Дневная цель</p>
            <p className="text-xs text-white/50 font-display">
              {Math.min(todayXP, dailyGoal)}/{dailyGoal} XP
            </p>
          </div>
          <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
            <div
              className="h-full rounded-full transition-[width] duration-500"
              style={{ width: `${Math.min(100, (todayXP / dailyGoal) * 100)}%`, background: "linear-gradient(90deg,#21e6c1,#3effd0)" }}
            />
          </div>
        </div>
        {todayXP >= dailyGoal && (
          <span className="shrink-0 rounded-full bg-[#21e6c1]/15 px-2.5 py-1 text-[10px] font-semibold text-[#21e6c1]">Цель дня взята</span>
        )}
      </div>

      {/* Вайс-забег */}
      <motion.button
        whileTap={{ scale: 0.98 }}
        onClick={() => {
          sfx.tap();
          onStartMixed();
        }}
        className="neon-glow-pink anim-glow relative w-full overflow-hidden rounded-2xl p-[1px] text-left"
      >
        <div className="rounded-2xl bg-[#160a2b] p-4">
          <div className="flex items-center gap-4">
            <div
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl"
              style={{ background: "linear-gradient(135deg,#ff2e7e,#ff8a1e)" }}
            >
              <Play className="h-6 w-6 text-white" fill="white" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-display text-lg leading-tight text-vice">ВАЙС-ЗАБЕГ</p>
              <p className="text-xs text-white/60 mt-0.5">Микс-квиз из всех районов · 12 слов · 3 жизни</p>
            </div>
            <ChevronRight className="h-5 w-5 shrink-0 text-white/40" />
          </div>
        </div>
      </motion.button>

      {/* Наборы */}
      <div>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-display text-sm tracking-[0.25em] text-white/70">РАЙОНЫ · НАБОРЫ СЛОВ</h2>
          <span className="text-[11px] text-white/40">
            {masteredTotal}/{totalWords} выучено
          </span>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {PACKS.map((p, i) => (
            <PackCard key={p.id} pack={p} index={i} stats={stats} onOpen={() => {
              sfx.tap();
              onOpenPack(p.id);
            }} />
          ))}
        </div>
      </div>
    </div>
  );
}

function calcStreakSafe(days: string[]): number {
  // ленивый импорт избегаем — функция чистая, дублируем логику через локальный расчёт
  const set = new Set(days);
  let streak = 0;
  const d = new Date();
  const key = (x: Date) =>
    `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, "0")}-${String(x.getDate()).padStart(2, "0")}`;
  if (!set.has(key(d))) d.setDate(d.getDate() - 1);
  while (set.has(key(d))) {
    streak++;
    d.setDate(d.getDate() - 1);
  }
  return streak;
}

function PackCard({ pack, index, stats, onOpen }: { pack: Pack; index: number; stats: Record<string, import("@/lib/store").WordStat>; onOpen: () => void }) {
  const words = wordsOf(pack.id);
  const mastered = words.filter((w) => isMastered(stats[w.id])).length;
  const Icon = ICONS[pack.icon];
  const pct = Math.round((mastered / words.length) * 100);

  return (
    <motion.button
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      whileTap={{ scale: 0.97 }}
      onClick={onOpen}
      className="glass group relative overflow-hidden rounded-2xl text-left transition-colors hover:border-white/20"
    >
      <div className="relative">
        <img
          src={pack.image}
          alt={pack.titleRu}
          loading="lazy"
          className="block aspect-[4/3] w-full object-cover transition-transform duration-300 group-hover:scale-[1.04]"
        />
        <div
          className="pointer-events-none absolute inset-0"
          style={{ background: "linear-gradient(180deg, rgba(11,2,23,0.1) 35%, rgba(11,2,23,0.85) 100%)" }}
        />
        <div
          className="absolute left-3 top-3 flex h-9 w-9 items-center justify-center rounded-xl"
          style={{ background: `${pack.color}26`, boxShadow: `0 0 18px -6px ${pack.color}` }}
        >
          <Icon className="h-5 w-5" style={{ color: pack.color }} />
        </div>
        {pct === 100 && (
          <span className="absolute right-3 top-3 rounded-full bg-[#21e6c1]/25 px-2 py-0.5 text-[10px] font-bold text-[#3effd0] backdrop-blur-sm">
            РАЙОН ЧИСТ
          </span>
        )}
      </div>
      <div className="p-3.5">
        <p className="font-display text-sm leading-tight tracking-wide text-white/90">{pack.title}</p>
        <p className="mt-0.5 text-[11px] text-white/50">{pack.titleRu}</p>
        <div className="mt-3 h-1 w-full overflow-hidden rounded-full bg-white/10">
          <div className="h-full rounded-full transition-[width] duration-500" style={{ width: `${pct}%`, background: pack.color }} />
        </div>
        <p className="mt-1.5 text-[10px] text-white/40">
          {mastered}/{words.length} выучено
        </p>
      </div>
    </motion.button>
  );
}
