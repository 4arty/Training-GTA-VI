"use client";

import { useState } from "react";
import { ArrowLeft, BookOpen, Crosshair, ListChecks } from "lucide-react";
import { getPack, wordsOf, type PackId } from "@/lib/words";
import { isMastered, useProgress } from "@/lib/store";
import { speakWord, sfx } from "@/lib/sfx";
import { hapticLight } from "@/lib/telegram";
import { Volume2 } from "lucide-react";

interface Props {
  packId: PackId;
  onBack: () => void;
  onStartCards: () => void;
  onStartQuiz: () => void;
}

export function PackScreen({ packId, onBack, onStartCards, onStartQuiz }: Props) {
  const pack = getPack(packId);
  const words = wordsOf(packId);
  const stats = useProgress((s) => s.stats);
  const [open, setOpen] = useState<string | null>(null);

  const mastered = words.filter((w) => isMastered(stats[w.id])).length;
  const learning = words.filter((w) => !isMastered(stats[w.id]) && (stats[w.id]?.seen ?? 0) > 0).length;

  return (
    <div className="space-y-5 anim-rise">
      <button onClick={onBack} className="flex items-center gap-2 text-sm text-white/60 transition-colors hover:text-white">
        <ArrowLeft className="h-4 w-4" /> К районам
      </button>

      <div className="glass overflow-hidden rounded-2xl" style={{ boxShadow: `0 0 32px -14px ${pack.color}` }}>
        <div className="relative">
          <img
            src={pack.image}
            alt={pack.titleRu}
            className="block aspect-[21/9] w-full object-cover"
          />
          <div
            className="pointer-events-none absolute inset-0"
            style={{ background: "linear-gradient(180deg, rgba(11,2,23,0.15) 25%, rgba(11,2,23,0.88) 100%)" }}
          />
          <div className="absolute bottom-3 left-5 right-5">
            <p className="text-[10px] uppercase tracking-[0.25em]" style={{ color: pack.color }}>
              {pack.title}
            </p>
            <h1 className="font-display text-2xl mt-0.5">{pack.titleRu}</h1>
          </div>
        </div>
        <div className="p-5">
          <p className="text-sm text-white/55">{pack.desc}</p>
          <div className="mt-4 flex gap-2 text-[11px]">
            <span className="rounded-full bg-white/8 px-3 py-1 text-white/70">{words.length} слов</span>
            <span className="rounded-full bg-[#21e6c1]/12 px-3 py-1 text-[#21e6c1]">{mastered} выучено</span>
            {learning > 0 && <span className="rounded-full bg-[#ff8a1e]/12 px-3 py-1 text-[#ff8a1e]">{learning} в процессе</span>}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => {
            sfx.tap();
            hapticLight();
            onStartCards();
          }}
          className="glass flex items-center justify-center gap-2 rounded-2xl px-4 py-3.5 text-sm font-semibold transition-colors hover:border-white/25"
        >
          <BookOpen className="h-4 w-4 text-[#c86bff]" /> Учить карточки
        </button>
        <button
          onClick={() => {
            sfx.tap();
            hapticLight();
            onStartQuiz();
          }}
          className="neon-glow-pink flex items-center justify-center gap-2 rounded-2xl px-4 py-3.5 text-sm font-bold"
          style={{ background: "linear-gradient(135deg,#ff2e7e,#ff8a1e)", color: "#1a0512" }}
        >
          <Crosshair className="h-4 w-4" /> Пройти квиз
        </button>
      </div>

      <div>
        <div className="mb-2 flex items-center gap-2">
          <ListChecks className="h-4 w-4 text-white/50" />
          <h2 className="font-display text-sm tracking-[0.25em] text-white/70">СЛОВАРЬ РАЙОНА</h2>
        </div>
        <div className="space-y-1.5">
          {words.map((w) => {
            const st = stats[w.id];
            const m = isMastered(st);
            const seen = (st?.seen ?? 0) > 0;
            const isOpen = open === w.id;
            return (
              <div
                key={w.id}
                className="glass overflow-hidden rounded-xl transition-colors"
                style={m ? { borderColor: "rgba(33,230,193,0.35)" } : undefined}
              >
                <button
                  className="flex w-full items-center gap-3 px-4 py-3 text-left"
                  onClick={() => {
                    sfx.flip();
                    setOpen(isOpen ? null : w.id);
                  }}
                >
                  <span
                    className="h-2 w-2 shrink-0 rounded-full"
                    style={{ background: m ? "#21e6c1" : seen ? "#ff8a1e" : "rgba(255,255,255,0.25)" }}
                  />
                  <span className="w-[42%] shrink-0 min-w-0">
                    <span className="block truncate text-sm font-semibold">{w.en}</span>
                  </span>
                  <span className="flex-1 truncate text-sm text-white/55">{w.ru}</span>
                  <span
                    onClick={(e) => {
                      e.stopPropagation();
                      speakWord(w.en);
                      hapticLight();
                    }}
                    className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg transition-colors hover:bg-white/10"
                    role="button"
                    aria-label={`Озвучить ${w.en}`}
                  >
                    <Volume2 className="h-4 w-4 text-white/50" />
                  </span>
                </button>
                {isOpen && (
                  <div className="border-t border-white/8 px-4 py-3 anim-rise">
                    <p className="text-xs text-white/40">{w.ipa}</p>
                    <p className="mt-1.5 text-sm italic text-[#ffc233]/90">«{w.ex}»</p>
                    <p className="mt-1 text-xs text-white/55">{w.exRu}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
