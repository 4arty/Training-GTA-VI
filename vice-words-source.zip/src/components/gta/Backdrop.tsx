"use client";

// Неоновый фон Vice City: солнце, пальмы, перспективная сетка, сканлайны
export function Backdrop() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      {/* Неоновое солнце */}
      <div className="absolute left-1/2 top-[72px] h-[300px] w-[300px] -translate-x-1/2 anim-float">
        <div
          className="h-full w-full rounded-full"
          style={{
            background: "radial-gradient(circle at 50% 60%, #ffc233 0%, #ff8a1e 34%, #ff2e7e 66%, rgba(255,46,126,0.15) 82%, transparent 100%)",
            filter: "blur(1px)",
            opacity: 0.5,
          }}
        />
        {/* Горизонтальные полосы на нижней половине солнца */}
        <div
          className="absolute inset-0 rounded-full"
          style={{
            background: "repeating-linear-gradient(to top, #0b0217 0 6px, transparent 6px 14px)",
            maskImage: "linear-gradient(to top, black 0%, transparent 46%)",
            WebkitMaskImage: "linear-gradient(to top, black 0%, transparent 46%)",
            opacity: 0.85,
          }}
        />
      </div>

      {/* Перспективная сетка */}
      <div className="absolute bottom-0 left-0 right-0 h-[36%] overflow-hidden">
        <div
          className="absolute bottom-[-40%] left-[-25%] right-[-25%] top-0"
          style={{
            background:
              "repeating-linear-gradient(90deg, rgba(255,46,126,0.13) 0 1.5px, transparent 1.5px 64px), repeating-linear-gradient(0deg, rgba(33,230,193,0.10) 0 1.5px, transparent 1.5px 48px)",
            transform: "perspective(340px) rotateX(62deg)",
            transformOrigin: "center top",
            maskImage: "linear-gradient(to bottom, transparent 0%, black 30%)",
            WebkitMaskImage: "linear-gradient(to bottom, transparent 0%, black 30%)",
          }}
        />
      </div>

      {/* Пальмы */}
      <Palm className="absolute -left-7 bottom-0 h-44 w-44 opacity-60" flip={false} />
      <Palm className="absolute -right-7 bottom-0 h-40 w-40 opacity-60" flip />

      {/* Сканлайны + виньетка */}
      <div
        className="absolute inset-0"
        style={{
          background: "repeating-linear-gradient(to bottom, rgba(255,255,255,0.025) 0 1px, transparent 1px 3px)",
        }}
      />
      <div
        className="absolute inset-0"
        style={{
          background: "radial-gradient(120% 90% at 50% 30%, transparent 55%, rgba(4,0,10,0.55) 100%)",
        }}
      />
    </div>
  );
}

function Palm({ className, flip }: { className?: string; flip?: boolean }) {
  return (
    <svg viewBox="0 0 120 150" className={className} style={flip ? { transform: "scaleX(-1)" } : undefined} fill="none">
      <path d="M56 150 C54 122 52 100 58 78" stroke="#180a33" strokeWidth="7" strokeLinecap="round" />
      <path d="M58 78 C34 68 22 72 6 86" stroke="#180a33" strokeWidth="6" strokeLinecap="round" />
      <path d="M58 78 C82 68 94 72 112 86" stroke="#180a33" strokeWidth="6" strokeLinecap="round" />
      <path d="M58 78 C44 52 30 48 14 52" stroke="#180a33" strokeWidth="6" strokeLinecap="round" />
      <path d="M58 78 C72 52 86 48 102 52" stroke="#180a33" strokeWidth="6" strokeLinecap="round" />
      <path d="M58 78 C54 48 44 38 32 34" stroke="#180a33" strokeWidth="5" strokeLinecap="round" />
      <path d="M58 78 C62 48 72 38 84 34" stroke="#180a33" strokeWidth="5" strokeLinecap="round" />
      <circle cx="58" cy="78" r="6" fill="#180a33" />
    </svg>
  );
}
