"use client";

import { useEffect, useRef, useState } from "react";

const TIPS: string[] = [
  '"heist" — ограбление. Главное слово этой игры.',
  '"hang tight" — это не «повиснуть», а «подожди, оставайся на месте».',
  '"whip" на улице — это тачка, а не кнут.',
  '"busted" — тебя повели. "wasted" — ты труп. Разница важна.',
  '"cut" в банде — доля от добычи, не порез.',
  '"beef" — это тёрки, а не говядина.',
  'Озвучка в GTA VI только английская. Слова из "STREET TALK" услышишь чаще всего.',
  '"stash" — тайник. Обычно именно его хотят найти.',
  '"pull over" — так копы требуют прижаться к обочине.',
  '"double-cross" — кинуть своих. В Вайс-Сити это случается.',
];

export function BootScreen({ onDone }: { onDone: () => void }) {
  const [progress, setProgress] = useState(0);
  const [tip, setTip] = useState(0);
  const doneRef = useRef(false);

  useEffect(() => {
    const iv = setInterval(() => {
      setProgress((p) => {
        const next = p + Math.random() * 16 + 9;
        return next >= 100 ? 100 : next;
      });
    }, 110);
    const tv = setInterval(() => setTip((t) => (t + 1) % TIPS.length), 900);
    // Страховка: даже если таймеры замедлены (фоновая вкладка), заставка закроется сама
    const fallback = setTimeout(onDone, 4000);
    return () => {
      clearInterval(iv);
      clearInterval(tv);
      clearTimeout(fallback);
    };
  }, [onDone]);

  useEffect(() => {
    if (progress >= 100 && !doneRef.current) {
      doneRef.current = true;
      const t = setTimeout(onDone, 450);
      return () => clearTimeout(t);
    }
  }, [progress, onDone]);

  return (
    <button
      type="button"
      onClick={onDone}
      aria-label="Пропустить заставку"
      className="fixed inset-0 z-[60] flex w-full cursor-pointer flex-col items-center justify-center bg-[#0b0217] px-6 text-left"
    >
      <div className="flex flex-col items-center">
        <p className="font-display text-[11px] tracking-[0.5em] text-[#21e6c1] mb-3 anim-flicker">LEONIDA PRESENTS</p>
        <h1 className="font-display text-6xl sm:text-7xl tracking-wide anim-pop">
          <span className="text-vice">VICE</span>{" "}
          <span className="text-teal-neon">WORDS</span>
        </h1>
        <p className="mt-3 text-xs tracking-[0.3em] text-white/60 font-display">WORD HEIST · VICE CITY</p>
      </div>

      <div className="mt-14 w-full max-w-xs">
        <div className="relative h-1.5 w-full overflow-hidden rounded-full bg-white/10">
          {progress === 0 && <div className="anim-boot-shimmer" />}
          {progress > 0 && (
            <div
              className="h-full rounded-full transition-[width] duration-150 ease-out"
              style={{
                width: `${progress}%`,
                background: "linear-gradient(90deg, #ffc233, #ff8a1e, #ff2e7e)",
              }}
            />
          )}
        </div>
        <div className="mt-4 flex items-center justify-between text-[11px] text-white/50">
          <span className="truncate pr-3">{TIPS[tip]}</span>
          <span className="font-display shrink-0">{Math.round(progress)}%</span>
        </div>
      </div>

      <p className="anim-hint-pulse absolute bottom-9 text-[11px] font-semibold tracking-[0.25em] text-white/90 font-display">
        НАЖМИТЕ НА ЭКРАН, ЧТОБЫ ПРОДОЛЖИТЬ
      </p>
      <p className="absolute bottom-5 text-[9px] tracking-[0.35em] text-white/30 font-display">TAP TO SKIP</p>
    </button>
  );
}
