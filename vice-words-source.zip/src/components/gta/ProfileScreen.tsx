"use client";

import { useMemo } from "react";
import {
  Award,
  Crown,
  Flame,
  Gauge,
  Lock,
  RefreshCcw,
  Share2,
  Sparkles,
  Star,
  Target,
  Trophy,
  Volume2,
  VolumeX,
  Zap,
} from "lucide-react";
import { ALL_WORDS, PACKS, wordsOf } from "@/lib/words";
import { calcStreak, getRank, isMastered, useProgress } from "@/lib/store";
import { shareProgress } from "@/lib/telegram";
import { Switch } from "@/components/ui/switch";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export function ProfileScreen() {
  const xp = useProgress((s) => s.xp);
  const stats = useProgress((s) => s.stats);
  const goalDays = useProgress((s) => s.goalDays);
  const runs = useProgress((s) => s.runs);
  const perfects = useProgress((s) => s.perfects);
  const sound = useProgress((s) => s.sound);
  const setSound = useProgress((s) => s.setSound);
  const resetAll = useProgress((s) => s.resetAll);

  const rank = getRank(xp);
  const streak = calcStreak(goalDays);

  const totalAnswers = useMemo(() => Object.values(stats).reduce((a, s) => a + s.correct + s.wrong, 0), [stats]);
  const totalCorrect = useMemo(() => Object.values(stats).reduce((a, s) => a + s.correct, 0), [stats]);
  const masteredCount = useMemo(() => ALL_WORDS.filter((w) => isMastered(stats[w.id])).length, [stats]);
  const accuracy = totalAnswers > 0 ? Math.round((totalCorrect / totalAnswers) * 100) : 0;
  const streetDone = useMemo(() => {
    const ws = wordsOf("street");
    return ws.every((w) => isMastered(stats[w.id]));
  }, [stats]);

  const share = () => {
    const appUrl = typeof window !== "undefined" ? window.location.href.split("?")[0] : "";
    shareProgress(
      appUrl,
      `VICE WORDS: я выучил ${masteredCount} из ${ALL_WORDS.length} слов для прохождения GTA VI. Мой ранг — «${rank.title}» (${xp} XP). Присоединяйся!`
    );
  };

  const achievements = [
    { id: "first", icon: Sparkles, title: "Первый хит", desc: "Первый верный ответ", done: totalCorrect >= 1 },
    { id: "run", icon: Target, title: "Первое дело", desc: "Пройти первый квиз", done: runs >= 1 },
    { id: "perfect", icon: Star, title: "Безупречно", desc: "Квиз без ошибок", done: perfects >= 1 },
    { id: "thirty", icon: Gauge, title: "Полевой игрок", desc: "30 слов выучено", done: masteredCount >= 30 },
    { id: "rich", icon: Trophy, title: "Навар", desc: "500 XP заработано", done: xp >= 500 },
    { id: "streak", icon: Flame, title: "Разогрев", desc: "3 дня подряд по цели", done: streak >= 3 },
    { id: "street", icon: Crown, title: "Знаток улиц", desc: "Весь «Street Talk» выучен", done: streetDone },
    { id: "all", icon: Crown, title: "Легенда Леониды", desc: "Все слова выучены", done: masteredCount >= ALL_WORDS.length },
  ];

  return (
    <div className="space-y-5 anim-rise">
      <h1 className="font-display text-2xl tracking-wide">
        ЛИЧНОЕ <span className="text-vice">ДЕЛО</span>
      </h1>

      {/* Ранг */}
      <div className="glass rounded-2xl p-5 text-center" style={{ boxShadow: "0 0 40px -16px #ff2e7e" }}>
        <p className="text-[10px] uppercase tracking-[0.3em] text-white/45">текущий ранг</p>
        <p className="mt-2 font-display text-2xl text-vice">{rank.title}</p>
        <div className="mx-auto mt-4 h-1.5 w-full max-w-xs overflow-hidden rounded-full bg-white/10">
          <div className="h-full rounded-full" style={{ width: `${Math.round(rank.progress * 100)}%`, background: "linear-gradient(90deg,#ff2e7e,#ffc233)" }} />
        </div>
        <p className="mt-2 text-xs text-white/50">
          {xp} XP {rank.nextMin ? `· до «${rank.nextTitle}» ${rank.nextMin - xp} XP` : "· максимум"}
        </p>
      </div>

      {/* Статистика */}
      <div className="grid grid-cols-3 gap-2.5">
        <StatBox value={`${masteredCount}/${ALL_WORDS.length}`} label="слов выучено" color="#21e6c1" />
        <StatBox value={`${accuracy}%`} label="точность" color="#ff8a1e" />
        <StatBox value={`${totalAnswers}`} label="ответов" color="#c86bff" />
        <StatBox value={`${runs}`} label="квизов" color="#ff2e7e" />
        <StatBox value={`${perfects}`} label="идеальных" color="#ffc233" />
        <StatBox value={`${streak}`} label="дней стрик" color="#3effd0" />
      </div>

      {/* Достижения */}
      <div>
        <h2 className="mb-3 font-display text-sm tracking-[0.25em] text-white/70">ТРОФЕИ</h2>
        <div className="grid grid-cols-2 gap-3">
          {achievements.map((a) => (
            <div
              key={a.id}
              className="glass rounded-2xl p-4 flex items-start gap-3 transition-opacity"
              style={{ opacity: a.done ? 1 : 0.45, borderColor: a.done ? "rgba(255,194,51,0.4)" : undefined }}
            >
              <div
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl"
                style={{
                  background: a.done ? "rgba(255,194,51,0.15)" : "rgba(255,255,255,0.05)",
                  boxShadow: a.done ? "0 0 18px -6px #ffc233" : undefined,
                }}
              >
                {a.done ? <a.icon className="h-4.5 w-4.5 text-[#ffc233]" /> : <Lock className="h-4 w-4 text-white/35" />}
              </div>
              <div className="min-w-0">
                <p className="text-xs font-bold leading-tight">{a.title}</p>
                <p className="mt-0.5 text-[10px] text-white/45 leading-snug">{a.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Настройки */}
      <div className="glass rounded-2xl divide-y divide-white/8">
        <div className="flex items-center justify-between px-4 py-3.5">
          <div className="flex items-center gap-3">
            {sound ? <Volume2 className="h-4 w-4 text-[#21e6c1]" /> : <VolumeX className="h-4 w-4 text-white/40" />}
            <div>
              <p className="text-sm font-semibold">Звуковые эффекты</p>
              <p className="text-[10px] text-white/40">Отклик на верные и неверные ответы</p>
            </div>
          </div>
          <Switch checked={sound} onCheckedChange={setSound} />
        </div>
        <button onClick={share} className="flex w-full items-center justify-between px-4 py-3.5 text-left transition-colors hover:bg-white/5">
          <div className="flex items-center gap-3">
            <Share2 className="h-4 w-4 text-[#c86bff]" />
            <div>
              <p className="text-sm font-semibold">Поделиться успехом</p>
              <p className="text-[10px] text-white/40">Отправить ранг и статистику в чат</p>
            </div>
          </div>
          <Award className="h-4 w-4 text-white/30" />
        </button>
        <div className="px-4 py-3.5">
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <button className="flex w-full items-center justify-between text-left">
                <div className="flex items-center gap-3">
                  <RefreshCcw className="h-4 w-4 text-[#ff3b5c]" />
                  <div>
                    <p className="text-sm font-semibold text-[#ff3b5c]">Сбросить прогресс</p>
                    <p className="text-[10px] text-white/40">Всё сгорело — как после WASTED</p>
                  </div>
                </div>
                <Zap className="h-4 w-4 text-white/30" />
              </button>
            </AlertDialogTrigger>
            <AlertDialogContent className="bg-[#1a0d30] border-white/15 text-white">
              <AlertDialogHeader>
                <AlertDialogTitle className="font-display">Начать жизнь с чистого листа?</AlertDialogTitle>
                <AlertDialogDescription className="text-white/60">
                  XP, выученные слова, стрик и трофеи будут удалены безвозвратно.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel className="bg-white/10 border-white/15 text-white hover:bg-white/15">Отмена</AlertDialogCancel>
                <AlertDialogAction
                  className="bg-[#ff3b5c] text-white hover:bg-[#ff3b5c]/85"
                  onClick={() => {
                    resetAll();
                  }}
                >
                  Сбросить всё
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      <p className="pb-2 text-center text-[10px] text-white/30">
        VICE WORDS · фанатский тренажёр · {PACKS.length} районов, {ALL_WORDS.length} слов
      </p>
    </div>
  );
}

function StatBox({ value, label, color }: { value: string; label: string; color: string }) {
  return (
    <div className="glass rounded-2xl p-3 text-center">
      <p className="font-display text-lg leading-tight" style={{ color }}>
        {value}
      </p>
      <p className="mt-0.5 text-[9px] text-white/45 leading-tight">{label}</p>
    </div>
  );
}
