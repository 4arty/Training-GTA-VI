"use client";

// Тонкая обёртка над Telegram Mini App SDK — всё опционально,
// в обычном браузере приложение работает без него.

export interface TgWebApp {
  ready(): void;
  expand(): void;
  close(): void;
  setHeaderColor?(c: string): void;
  setBackgroundColor?(c: string): void;
  disableVerticalSwipes?(): void;
  HapticFeedback?: {
    impactOccurred(style: "light" | "medium" | "heavy" | "rigid" | "soft"): void;
    notificationOccurred(type: "error" | "success" | "warning"): void;
    selectionChanged(): void;
  };
  BackButton?: {
    show(): void;
    hide(): void;
    onClick(cb: () => void): void;
    offClick(cb: () => void): void;
    isVisible: boolean;
  };
  openTelegramLink?(url: string): void;
  initDataUnsafe?: { user?: { first_name?: string; username?: string } };
}

export function tg(): TgWebApp | null {
  if (typeof window === "undefined") return null;
  const t = (window as unknown as { Telegram?: { WebApp?: TgWebApp } }).Telegram?.WebApp;
  return t ?? null;
}

export const inTelegram = () => !!tg()?.initDataUnsafe?.user;

export function initTelegram() {
  const t = tg();
  if (!t) return;
  try {
    t.ready();
    t.expand();
    t.setHeaderColor?.("#0b0217");
    t.setBackgroundColor?.("#0b0217");
    t.disableVerticalSwipes?.();
  } catch {
    /* ignore */
  }
}

export function hapticLight() {
  try {
    tg()?.HapticFeedback?.impactOccurred("light");
  } catch {
    /* ignore */
  }
}

export function hapticMedium() {
  try {
    tg()?.HapticFeedback?.impactOccurred("medium");
  } catch {
    /* ignore */
  }
}

export function hapticNotify(ok: boolean) {
  try {
    tg()?.HapticFeedback?.notificationOccurred(ok ? "success" : "error");
  } catch {
    /* ignore */
  }
}

export function tgUserName(): string | null {
  return tg()?.initDataUnsafe?.user?.first_name ?? null;
}

export function shareProgress(appUrl: string, text: string) {
  const link = `https://t.me/share/url?url=${encodeURIComponent(appUrl)}&text=${encodeURIComponent(text)}`;
  const t = tg();
  if (t?.openTelegramLink) t.openTelegramLink(link);
  else window.open(link, "_blank");
}
