// VICE WORDS — база игровых слов для прохождения GTA VI (озвучка в игре только английская)
export type PackId = "missions" | "combat" | "driving" | "police" | "money" | "street";

export interface Word {
  id: string;
  en: string;
  ipa: string;
  ru: string;
  ex: string;
  exRu: string;
  pack: PackId;
}

export interface Pack {
  id: PackId;
  title: string;
  titleRu: string;
  desc: string;
  icon: "target" | "crosshair" | "car" | "siren" | "banknote" | "chat";
  color: string;
  image: string;
}

export const PACKS: Pack[] = [
  {
    id: "missions",
    title: "MISSION BRIEFING",
    titleRu: "Первое дело",
    desc: "Слова из брифингов и заданий: цели, засады, точки встречи.",
    icon: "target",
    color: "#ff2e7e",
    image: "/img/pack-missions.webp",
  },
  {
    id: "combat",
    title: "GUNFIGHT",
    titleRu: "Огневой контакт",
    desc: "Оружие, перезарядка, укрытия — всё, что слышно в перестрелке.",
    icon: "crosshair",
    color: "#ff5c47",
    image: "/img/pack-combat.webp",
  },
  {
    id: "driving",
    title: "HIGH SPEED",
    titleRu: "Погоня",
    desc: "Вождение и погони: газ, тормоз, таран, перекрёсток.",
    icon: "car",
    color: "#ff8a1e",
    image: "/img/pack-driving.webp",
  },
  {
    id: "police",
    title: "HEAT",
    titleRu: "Розыск",
    desc: "Полиция и розыск: сирены, ордер, алиби, под прикрытием.",
    icon: "siren",
    color: "#21e6c1",
    image: "/img/pack-police.webp",
  },
  {
    id: "money",
    title: "DIRTY MONEY",
    titleRu: "Навар",
    desc: "Деньги и сделки: доля, тайник, отмывание, выкуп.",
    icon: "banknote",
    color: "#ffc233",
    image: "/img/pack-money.webp",
  },
  {
    id: "street",
    title: "STREET TALK",
    titleRu: "Уличный жаргон",
    desc: "Слэнг из диалогов: стукач, тёрки, подстава, береги спину.",
    icon: "chat",
    color: "#c86bff",
    image: "/img/pack-street.webp",
  },
];

export const ALL_WORDS: Word[] = [
  // ─── MISSION BRIEFING ─────────────────────────────────────────────
  { id: "mission", en: "mission", ipa: "/ˈmɪʃən/", ru: "миссия", ex: "The mission starts at midnight.", exRu: "Миссия начнётся в полночь.", pack: "missions" },
  { id: "objective", en: "objective", ipa: "/ˈɒbdʒektɪv/", ru: "цель, задача", ex: "Check the objective marker on the map.", exRu: "Глянь маркер задачи на карте.", pack: "missions" },
  { id: "heist", en: "heist", ipa: "/haɪst/", ru: "ограбление", ex: "The final heist took months to plan.", exRu: "На планирование финального ограбления ушли месяцы.", pack: "missions" },
  { id: "target", en: "target", ipa: "/ˈtɑːɡɪt/", ru: "цель, мишень", ex: "Do not lose the target.", exRu: "Не упусти цель из виду.", pack: "missions" },
  { id: "ambush", en: "ambush", ipa: "/ˈæmbʊʃ/", ru: "засада", ex: "It's an ambush — get out of the car!", exRu: "Это засада — вылезай из машины!", pack: "missions" },
  { id: "backup", en: "backup", ipa: "/ˈbækʌp/", ru: "подмога, поддержка", ex: "We need backup, now!", exRu: "Нам нужна подмога, и быстро!", pack: "missions" },
  { id: "stealth", en: "stealth", ipa: "/stelθ/", ru: "скрытность", ex: "Take a stealth approach — no shots.", exRu: "Действуй скрытно — без выстрелов.", pack: "missions" },
  { id: "escape", en: "escape", ipa: "/ɪˈskeɪp/", ru: "побег; сбежать", ex: "The escape route is through the docks.", exRu: "Путь отхода идёт через доки.", pack: "missions" },
  { id: "getaway", en: "getaway", ipa: "/ˈɡetəweɪ/", ru: "машина для отхода; побег", ex: "Keep the getaway car running.", exRu: "Не глушим тачку для отхода.", pack: "missions" },
  { id: "decoy", en: "decoy", ipa: "/ˈdɪkɔɪ/", ru: "приманка, отвлечение", ex: "Send in the decoy to distract the guards.", exRu: "Отправь приманку, чтобы отвлечь охрану.", pack: "missions" },
  { id: "recon", en: "recon", ipa: "/ˈriːkɒn/", ru: "разведка", ex: "Do some recon before we move in.", exRu: "Проведи разведку, прежде чем мы двинемся.", pack: "missions" },
  { id: "loadout", en: "loadout", ipa: "/ˈləʊdaʊt/", ru: "снаряжение, экипировка", ex: "Choose your loadout before the mission.", exRu: "Выбери снаряжение перед миссией.", pack: "missions" },
  { id: "checkpoint", en: "checkpoint", ipa: "/ˈtʃekpɔɪnt/", ru: "контрольная точка", ex: "You missed a checkpoint, turn around.", exRu: "Ты проехал контрольную точку, развернись.", pack: "missions" },
  { id: "rendezvous", en: "rendezvous", ipa: "/ˈrɒndɪvuː/", ru: "точка встречи", ex: "Our rendezvous is the old lighthouse.", exRu: "Наша точка встречи — старый маяк.", pack: "missions" },
  { id: "stakeout", en: "stakeout", ipa: "/ˈsteɪkaʊt/", ru: "слежка из засады", ex: "The stakeout lasted three days.", exRu: "Наблюдение из засады длилось три дня.", pack: "missions" },
  { id: "cleanup", en: "cleanup", ipa: "/ˈkliːnʌp/", ru: "зачистка следов", ex: "Leave the cleanup to me.", exRu: "Оставь зачистку следов мне.", pack: "missions" },
  { id: "abort", en: "abort", ipa: "/əˈbɔːt/", ru: "отменить операцию", ex: "Abort the mission, cops everywhere.", exRu: "Отменяй операцию, кругом полиция.", pack: "missions" },
  { id: "hostage", en: "hostage", ipa: "/ˈhɒstɪdʒ/", ru: "заложник", ex: "Nobody shoots the hostage.", exRu: "Заложника никто не трогает.", pack: "missions" },

  // ─── GUNFIGHT ─────────────────────────────────────────────────────
  { id: "ammo", en: "ammo", ipa: "/ˈæməʊ/", ru: "патроны", ex: "I'm low on ammo.", exRu: "У меня мало патронов.", pack: "combat" },
  { id: "reload", en: "reload", ipa: "/riːˈləʊd/", ru: "перезарядить", ex: "Reload! I'll cover you.", exRu: "Перезаряжай! Я прикрою.", pack: "combat" },
  { id: "cover", en: "cover", ipa: "/ˈkʌvə/", ru: "укрытие; прикрывать", ex: "Take cover behind the wall.", exRu: "Займи укрытие за стеной.", pack: "combat" },
  { id: "melee", en: "melee", ipa: "/ˈmeleɪ/", ru: "ближний бой", ex: "Switch to melee if they get close.", exRu: "Переключись на ближний бой, если подойдут вплотную.", pack: "combat" },
  { id: "silencer", en: "silencer", ipa: "/ˈsaɪlənsə/", ru: "глушитель", ex: "A silenced pistol is perfect for stealth.", exRu: "Пистолет с глушителем идеален для тихой работы.", pack: "combat" },
  { id: "holster", en: "holster", ipa: "/ˈhəʊlstə/", ru: "кобура", ex: "Keep it in the holster.", exRu: "Держи его в кобуре.", pack: "combat" },
  { id: "recoil", en: "recoil", ipa: "/ˈriːkɔɪl/", ru: "отдача", ex: "This rifle has a heavy recoil.", exRu: "У этой винтовки сильная отдача.", pack: "combat" },
  { id: "armor", en: "armor", ipa: "/ˈɑːmə/", ru: "броня", ex: "Grab the armor before the shootout.", exRu: "Забери броню перед перестрелкой.", pack: "combat" },
  { id: "shootout", en: "shootout", ipa: "/ˈʃuːtaʊt/", ru: "перестрелка", ex: "A shootout broke out on the highway.", exRu: "На шоссе завязалась перестрелка.", pack: "combat" },
  { id: "firefight", en: "firefight", ipa: "/ˈfaɪəfaɪt/", ru: "огневой контакт", ex: "A short firefight, then silence.", exRu: "Короткий огневой контакт, потом тишина.", pack: "combat" },
  { id: "wounded", en: "wounded", ipa: "/ˈwuːndɪd/", ru: "раненый", ex: "He's wounded, call a doctor.", exRu: "Он ранен, вызывай врача.", pack: "combat" },
  { id: "grenade", en: "grenade", ipa: "/ɡrəˈneɪd/", ru: "граната", ex: "Toss the grenade through the window.", exRu: "Закинь гранату в окно.", pack: "combat" },
  { id: "scope", en: "scope", ipa: "/skəʊp/", ru: "прицел", ex: "Use the scope to watch the gate.", exRu: "Смотри за воротами через прицел.", pack: "combat" },
  { id: "trigger", en: "trigger", ipa: "/ˈtrɪɡə/", ru: "курок; спусковой крючок", ex: "Don't pull the trigger yet.", exRu: "Пока не нажимай на курок.", pack: "combat" },
  { id: "gunpoint", en: "gunpoint", ipa: "/ˈɡʌnpɔɪnt/", ru: "под дулом оружия", ex: "They robbed the store at gunpoint.", exRu: "Они ограбили магазин под дулом оружия.", pack: "combat" },

  // ─── HIGH SPEED ───────────────────────────────────────────────────
  { id: "throttle", en: "throttle", ipa: "/ˈθrɒtl/", ru: "газ, дроссель", ex: "Full throttle until the bridge!", exRu: "Полный газ до самого моста!", pack: "driving" },
  { id: "brake", en: "brake", ipa: "/breɪk/", ru: "тормоз", ex: "Hit the brakes!", exRu: "Тормози!", pack: "driving" },
  { id: "drift", en: "drift", ipa: "/drɪft/", ru: "дрифт, занос", ex: "Drift around the corner to lose them.", exRu: "Пройди поворот в дрифте, чтобы оторваться.", pack: "driving" },
  { id: "pursuit", en: "pursuit", ipa: "/pəˈsjuːt/", ru: "преследование", ex: "End the pursuit in the canals.", exRu: "Заверши преследование в каналах.", pack: "driving" },
  { id: "chase", en: "chase", ipa: "/tʃeɪs/", ru: "погоня", ex: "The chase was over in minutes.", exRu: "Погоня закончилась за считаные минуты.", pack: "driving" },
  { id: "wreck", en: "wreck", ipa: "/rek/", ru: "разбитая тачка", ex: "The car was a total wreck.", exRu: "Машина превратилась в груду металлолома.", pack: "driving" },
  { id: "chassis", en: "chassis", ipa: "/ˈʃæsi/", ru: "кузов, шасси", ex: "The chassis is damaged but it still runs.", exRu: "Кузов повреждён, но она ещё едет.", pack: "driving" },
  { id: "intersection", en: "intersection", ipa: "/ˌɪntəˈsekʃən/", ru: "перекрёсток", ex: "Wait for me at the intersection.", exRu: "Жди меня на перекрёстке.", pack: "driving" },
  { id: "highway", en: "highway", ipa: "/ˈhaɪweɪ/", ru: "шоссе", ex: "Take the highway north.", exRu: "Поезжай по шоссе на север.", pack: "driving" },
  { id: "ram", en: "ram", ipa: "/ræm/", ru: "таранить", ex: "Ram them off the road.", exRu: "Протарань их и столкни с дороги.", pack: "driving" },
  { id: "swerve", en: "swerve", ipa: "/swɜːv/", ru: "резко свернуть", ex: "Swerve left, there's a truck!", exRu: "Уворачивай влево, там фура!", pack: "driving" },
  { id: "lane", en: "lane", ipa: "/leɪn/", ru: "полоса движения", ex: "Stay in the left lane.", exRu: "Держись левой полосы.", pack: "driving" },
  { id: "pull-over", en: "pull over", ipa: "/pʊl ˈəʊvə/", ru: "прижаться к обочине", ex: "The cop yelled: pull over!", exRu: "Коп кричал: к обочине!", pack: "driving" },
  { id: "tailgate", en: "tailgate", ipa: "/ˈteɪlɡeɪt/", ru: "прижиматься к хвосту машины", ex: "Don't tailgate the truck.", exRu: "Не прижимайся к хвосту фуры.", pack: "driving" },
  { id: "hit-and-run", en: "hit and run", ipa: "/hɪt ənd rʌn/", ru: "наезд и бегство", ex: "That's a hit and run, they will hunt you.", exRu: "Это наезд и бегство, тебя будут искать.", pack: "driving" },

  // ─── HEAT ─────────────────────────────────────────────────────────
  { id: "warrant", en: "warrant", ipa: "/ˈwɒrənt/", ru: "ордер", ex: "They don't have a warrant.", exRu: "У них нет ордера.", pack: "police" },
  { id: "siren", en: "siren", ipa: "/ˈsaɪərən/", ru: "сирена", ex: "I hear sirens — drive faster.", exRu: "Слышу сирены — жми на газ.", pack: "police" },
  { id: "felony", en: "felony", ipa: "/ˈfeləni/", ru: "тяжкое преступление", ex: "That's a felony now.", exRu: "Теперь это тяжкое преступление.", pack: "police" },
  { id: "patrol", en: "patrol", ipa: "/pəˈtrəʊl/", ru: "патруль", ex: "The patrol circles the block every ten minutes.", exRu: "Патруль объезжает квартал каждые десять минут.", pack: "police" },
  { id: "arrest", en: "arrest", ipa: "/əˈrest/", ru: "арест; арестовать", ex: "She was arrested at the docks.", exRu: "Её арестовали в доках.", pack: "police" },
  { id: "busted", en: "busted", ipa: "/ˈbʌstɪd/", ru: "пойман, поведён", ex: "You're busted, hands up!", exRu: "Ты пойман, руки вверх!", pack: "police" },
  { id: "custody", en: "custody", ipa: "/ˈkʌstədi/", ru: "под стражей", ex: "He spent a night in custody.", exRu: "Он провёл ночь под стражей.", pack: "police" },
  { id: "suspect", en: "suspect", ipa: "/ˈsʌspekt/", ru: "подозреваемый", ex: "The suspect fled on foot.", exRu: "Подозреваемый сбежал пешком.", pack: "police" },
  { id: "witness", en: "witness", ipa: "/ˈwɪtnəs/", ru: "свидетель", ex: "No witnesses, no case.", exRu: "Нет свидетелей — нет дела.", pack: "police" },
  { id: "evidence", en: "evidence", ipa: "/ˈevɪdəns/", ru: "улики, доказательства", ex: "Get rid of the evidence.", exRu: "Избавься от улик.", pack: "police" },
  { id: "raid", en: "raid", ipa: "/reɪd/", ru: "облава, рейд", ex: "The cops raided the club.", exRu: "Копы устроили облаву в клубе.", pack: "police" },
  { id: "undercover", en: "undercover", ipa: "/ˌʌndəˈkʌvə/", ru: "под прикрытием", ex: "That buyer is undercover.", exRu: "Тот покупатель — под прикрытием.", pack: "police" },
  { id: "bounty", en: "bounty", ipa: "/ˈbaʊnti/", ru: "награда за поимку", ex: "There's a bounty on your head.", exRu: "За твою голову назначена награда.", pack: "police" },
  { id: "alibi", en: "alibi", ipa: "/ˈælɪbaɪ/", ru: "алиби", ex: "Get your alibi straight.", exRu: "Подготовь своё алиби.", pack: "police" },
  { id: "cuffed", en: "cuffed", ipa: "/kʌft/", ru: "в наручниках", ex: "He got cuffed and thrown in the car.", exRu: "Его скрутили и закинули в машину.", pack: "police" },

  // ─── DIRTY MONEY ──────────────────────────────────────────────────
  { id: "launder", en: "launder", ipa: "/ˈlɔːndə/", ru: "отмывать (деньги)", ex: "Launder the cash through the club.", exRu: "Отмой наличные через клуб.", pack: "money" },
  { id: "stash", en: "stash", ipa: "/stæʃ/", ru: "тайник, заначка", ex: "Half the stash is still missing.", exRu: "Половины тайника до сих пор нет.", pack: "money" },
  { id: "cut", en: "cut", ipa: "/kʌt/", ru: "доля (от добычи)", ex: "Everyone gets an equal cut.", exRu: "Каждый получает равную долю.", pack: "money" },
  { id: "loot", en: "loot", ipa: "/luːt/", ru: "добыча, хабар", ex: "Split the loot and disappear.", exRu: "Раздели добычу и исчезни.", pack: "money" },
  { id: "score", en: "score", ipa: "/skɔː/", ru: "удачное дело, навар", ex: "That last score set us up for life.", exRu: "То последнее дело обеспечило нас на всю жизнь.", pack: "money" },
  { id: "debt", en: "debt", ipa: "/det/", ru: "долг", ex: "You still owe him a debt.", exRu: "Ты всё ещё в долгу перед ним.", pack: "money" },
  { id: "bribe", en: "bribe", ipa: "/braɪb/", ru: "взятка", ex: "A small bribe opens many doors.", exRu: "Небольшая взятка открывает многие двери.", pack: "money" },
  { id: "cash", en: "cash", ipa: "/kæʃ/", ru: "наличные", ex: "Cash only, no traces.", exRu: "Только наличные, никаких следов.", pack: "money" },
  { id: "profit", en: "profit", ipa: "/ˈprɒfɪt/", ru: "прибыль", ex: "The profit from the job was huge.", exRu: "Навар с этого дела был огромный.", pack: "money" },
  { id: "owe", en: "owe", ipa: "/əʊ/", ru: "быть должным", ex: "I owe you one.", exRu: "Я у тебя в долгу.", pack: "money" },
  { id: "deal", en: "deal", ipa: "/diːl/", ru: "сделка", ex: "The deal goes down at midnight.", exRu: "Стрелка состоится в полночь.", pack: "money" },
  { id: "buyer", en: "buyer", ipa: "/ˈbaɪə/", ru: "покупатель", ex: "The buyer wants the goods tonight.", exRu: "Покупатель хочет товар сегодня ночью.", pack: "money" },
  { id: "invest", en: "invest", ipa: "/ɪnˈvest/", ru: "вложить, инвестировать", ex: "Invest your cut in the businesses.", exRu: "Вложи свою долю в бизнесы.", pack: "money" },
  { id: "ransom", en: "ransom", ipa: "/ˈrænsəm/", ru: "выкуп", ex: "They demanded a ransom.", exRu: "Они потребовали выкуп.", pack: "money" },
  { id: "counterfeit", en: "counterfeit", ipa: "/ˈkaʊntəfɪt/", ru: "фальшивый, подделка", ex: "They paid in counterfeit bills.", exRu: "Они заплатили фальшивыми купюрами.", pack: "money" },

  // ─── STREET TALK ──────────────────────────────────────────────────
  { id: "snitch", en: "snitch", ipa: "/snɪtʃ/", ru: "стукач; заложить", ex: "Nobody talks to a snitch.", exRu: "Со стукачом никто не разговаривает.", pack: "street" },
  { id: "beef", en: "beef", ipa: "/biːf/", ru: "тёрки, конфликт", ex: "We got no beef with them.", exRu: "У нас с ними нет тёрок.", pack: "street" },
  { id: "jack", en: "jack", ipa: "/dʒæk/", ru: "угнать; ограбить", ex: "Somebody tried to jack our truck.", exRu: "Кто-то пытался угнать наш грузовик.", pack: "street" },
  { id: "whip", en: "whip", ipa: "/wɪp/", ru: "тачка (слэнг)", ex: "Nice whip, is it new?", exRu: "Классная тачка, новая?", pack: "street" },
  { id: "ride", en: "ride", ipa: "/raɪd/", ru: "покатушка; подвезти", ex: "Give me a ride to the motel.", exRu: "Подвези меня до мотеля.", pack: "street" },
  { id: "hang-tight", en: "hang tight", ipa: "/hæŋ taɪt/", ru: "ждать, не двигаться", ex: "Hang tight, I'll be back in five.", exRu: "Оставайся на месте, вернусь через пять минут.", pack: "street" },
  { id: "rip-off", en: "rip off", ipa: "/rɪp ɒf/", ru: "кинуть, обмануть", ex: "He tried to rip us off.", exRu: "Он пытался нас кинуть.", pack: "street" },
  { id: "set-up", en: "set up", ipa: "/set ʌp/", ru: "подстава; подставить", ex: "It was a set up from the start.", exRu: "Это была подстава с самого начала.", pack: "street" },
  { id: "double-cross", en: "double-cross", ipa: "/ˌdʌblˈkrɒs/", ru: "предать, кинуть", ex: "He double-crossed the whole crew.", exRu: "Он кинул всю банду.", pack: "street" },
  { id: "crew", en: "crew", ipa: "/kruː/", ru: "банда, команда", ex: "You can't run a job without a crew.", exRu: "Нельзя провернуть дело без команды.", pack: "street" },
  { id: "boss", en: "boss", ipa: "/bɒs/", ru: "босс, шеф", ex: "The boss wants to see you.", exRu: "Босс хочет тебя видеть.", pack: "street" },
  { id: "betrayal", en: "betrayal", ipa: "/bɪˈtreɪəl/", ru: "предательство", ex: "Betrayal is never forgotten in Vice City.", exRu: "В Вайс-Сити предательство не забывают.", pack: "street" },
  { id: "loyalty", en: "loyalty", ipa: "/ˈlɔɪəlti/", ru: "верность, лояльность", ex: "In this business, loyalty is everything.", exRu: "В этом деле верность — всё.", pack: "street" },
  { id: "back-off", en: "back off", ipa: "/bæk ɒf/", ru: "отвали, отступи", ex: "Back off, this is our block.", exRu: "Отвали, это наш квартал.", pack: "street" },
  { id: "watch-your-back", en: "watch your back", ipa: "/wɒtʃ jɔː bæk/", ru: "береги спину", ex: "Watch your back out there.", exRu: "Там береги спину.", pack: "street" },
  { id: "stay-low", en: "stay low", ipa: "/steɪ ləʊ/", ru: "сидеть тихо, не отсвечивать", ex: "Stay low until the heat dies down.", exRu: "Сиди тихо, пока шум не уляжется.", pack: "street" },
];

export const wordsOf = (pack: PackId): Word[] => ALL_WORDS.filter((w) => w.pack === pack);
export const getPack = (id: PackId): Pack => PACKS.find((p) => p.id === id) as Pack;
export const getWord = (id: string): Word | undefined => ALL_WORDS.find((w) => w.id === id);

export const MASTER_STREAK = 3;
