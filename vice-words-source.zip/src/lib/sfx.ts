"use client";

// Мини-синтезатор на WebAudio — без внешних файлов
let ctx: AudioContext | null = null;
let enabled = true;

export function setSoundEnabled(v: boolean) {
  enabled = v;
}

function ac(): AudioContext | null {
  if (typeof window === "undefined") return null;
  try {
    if (!ctx) {
      const C = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!C) return null;
      ctx = new C();
    }
    if (ctx.state === "suspended") void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

function tone(freq: number, start: number, dur: number, type: OscillatorType = "sine", vol = 0.12) {
  const c = ac();
  if (!c || !enabled) return;
  try {
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = type;
    o.frequency.value = freq;
    const t0 = c.currentTime + start;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol, t0 + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g);
    g.connect(c.destination);
    o.start(t0);
    o.stop(t0 + dur + 0.05);
  } catch {
    /* ignore */
  }
}

export const sfx = {
  correct() {
    tone(660, 0, 0.12, "triangle", 0.14);
    tone(990, 0.09, 0.16, "triangle", 0.12);
  },
  wrong() {
    tone(180, 0, 0.28, "sawtooth", 0.1);
    tone(120, 0.12, 0.3, "sawtooth", 0.09);
  },
  pass() {
    [523, 659, 784, 1046].forEach((f, i) => tone(f, i * 0.11, 0.22, "triangle", 0.12));
  },
  wasted() {
    tone(300, 0, 0.3, "sawtooth", 0.1);
    tone(220, 0.25, 0.4, "sawtooth", 0.1);
    tone(150, 0.55, 0.6, "sawtooth", 0.1);
  },
  tap() {
    tone(520, 0, 0.05, "sine", 0.07);
  },
  flip() {
    tone(740, 0, 0.06, "sine", 0.05);
  },
  know() {
    tone(880, 0, 0.1, "triangle", 0.1);
    tone(1320, 0.08, 0.14, "triangle", 0.08);
  },
};

export function speakWord(en: string) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  try {
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(en);
    u.lang = "en-US";
    u.rate = 0.9;
    const v = window.speechSynthesis.getVoices().find((vo) => vo.lang?.toLowerCase().startsWith("en"));
    if (v) u.voice = v;
    window.speechSynthesis.speak(u);
  } catch {
    /* ignore */
  }
}
