"use client";

import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

export interface WordStat {
  seen: number;
  correct: number;
  wrong: number;
  streak: number;
  last: number;
}

export const RANKS = [
  { min: 0, title: "Новичок на районе" },
  { min: 150, title: "Мелкий воришка" },
  { min: 400, title: "Подельник" },
  { min: 800, title: "Уличный боец" },
  { min: 1400, title: "Профессионал" },
  { min: 2200, title: "Криминальный авторитет" },
  { min: 3200, title: "Легенда Вайс-Сити" },
];

export function getRank(xp: number) {
  let idx = 0;
  for (let i = 0; i < RANKS.length; i++) if (xp >= RANKS[i].min) idx = i;
  const cur = RANKS[idx];
  const next = RANKS[idx + 1];
  const progress = next ? Math.min(1, (xp - cur.min) / (next.min - cur.min)) : 1;
  return {
    index: idx + 1,
    title: cur.title,
    nextTitle: next?.title ?? null,
    nextMin: next?.min ?? null,
    progress,
  };
}

function dayKey(d = new Date()) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

/** Непрерывная серия дней, когда была выполнена дневная цель */
export function calcStreak(days: string[]): number {
  const set = new Set(days);
  let streak = 0;
  const d = new Date();
  if (!set.has(dayKey(d))) d.setDate(d.getDate() - 1);
  while (set.has(dayKey(d))) {
    streak++;
    d.setDate(d.getDate() - 1);
  }
  return streak;
}

export const isMastered = (s?: WordStat) =>
  !!s && (s.streak >= 3 || s.correct >= 6);

interface Store {
  xp: number;
  stats: Record<string, WordStat>;
  goalDays: string[];
  today: string;
  todayXP: number;
  dailyGoal: number;
  sound: boolean;
  runs: number;
  perfects: number;
  addXP: (n: number) => void;
  recordAnswer: (id: string, ok: boolean, xp?: number) => void;
  markSeen: (id: string) => void;
  finishRun: (perfect: boolean, bonus: number) => void;
  setSound: (v: boolean) => void;
  resetAll: () => void;
}

const initial = {
  xp: 0,
  stats: {} as Record<string, WordStat>,
  goalDays: [] as string[],
  today: "",
  todayXP: 0,
  dailyGoal: 20,
  sound: true,
  runs: 0,
  perfects: 0,
};

export const useProgress = create<Store>()(
  persist(
    (set, get) => {
      // Перенос дневного счётчика на новый день
      const rollDay = (s: Store): Partial<Store> => {
        const t = dayKey();
        if (s.today !== t) return { today: t, todayXP: 0 };
        return {};
      };
      return {
        ...initial,
        today: dayKey(),
        addXP: (n) =>
          set((s) => {
            const roll = rollDay(s);
            const todayXP = (roll.todayXP ?? s.todayXP) + n;
            const goalDays =
              todayXP >= s.dailyGoal && !s.goalDays.includes(roll.today ?? s.today)
                ? [...s.goalDays, roll.today ?? s.today]
                : s.goalDays;
            return { ...roll, xp: s.xp + n, todayXP, goalDays };
          }),
        recordAnswer: (id, ok, xp = ok ? 8 : 0) =>
          set((s) => {
            const prev: WordStat = s.stats[id] ?? { seen: 0, correct: 0, wrong: 0, streak: 0, last: 0 };
            const stat: WordStat = {
              seen: prev.seen + 1,
              correct: prev.correct + (ok ? 1 : 0),
              wrong: prev.wrong + (ok ? 0 : 1),
              streak: ok ? prev.streak + 1 : 0,
              last: Date.now(),
            };
            const roll = rollDay(s);
            const todayXP = (roll.todayXP ?? s.todayXP) + xp;
            const goalDays =
              todayXP >= s.dailyGoal && !s.goalDays.includes(roll.today ?? s.today)
                ? [...s.goalDays, roll.today ?? s.today]
                : s.goalDays;
            return {
              ...roll,
              stats: { ...s.stats, [id]: stat },
              xp: s.xp + xp,
              todayXP,
              goalDays,
            };
          }),
        markSeen: (id) =>
          set((s) => {
            const prev: WordStat = s.stats[id] ?? { seen: 0, correct: 0, wrong: 0, streak: 0, last: 0 };
            return {
              stats: { ...s.stats, [id]: { ...prev, seen: prev.seen + 1, last: Date.now() } },
            };
          }),
        finishRun: (perfect, bonus) =>
          set((s) => {
            const roll = rollDay(s);
            const todayXP = (roll.todayXP ?? s.todayXP) + bonus;
            const goalDays =
              todayXP >= s.dailyGoal && !s.goalDays.includes(roll.today ?? s.today)
                ? [...s.goalDays, roll.today ?? s.today]
                : s.goalDays;
            return {
              ...roll,
              runs: s.runs + 1,
              perfects: s.perfects + (perfect ? 1 : 0),
              xp: s.xp + bonus,
              todayXP,
              goalDays,
            };
          }),
        setSound: (v) => set({ sound: v }),
        resetAll: () => set({ ...initial, today: dayKey() }),
      };
    },
    {
      name: "vice-words-progress",
      storage: createJSONStorage(() => localStorage),
    }
  )
);
