#!/usr/bin/env bash
# VICE WORDS — быстрый запуск приложения.
#
# Почему не `next dev`: dev-режим отдаёт ~5 МБ несжатых JS-чанков (react-dom 1MB,
# devtools 0.8MB и т.д.). Через прокси превью они грузятся десятки секунд —
# пользователь видит заставку с 0% и думает, что приложение зависло.
# Production-сборка сжимает тот же код примерно в 8 раз и отдаётся со сжатием,
# поэтому здесь она основной способ запуска.
#
# Вызывается платформой при старте песочницы (start.sh предпочитает
# .zscripts/dev.sh вместо `bun run dev`).

cd /home/z/my-project || exit 1
export NODE_ENV=production

# Быстрый путь: standalone-сборка уже собрана — старт за <1 секунды.
if [ -f .next/standalone/server.js ] && [ -d .next/standalone/.next/static ]; then
  echo "[vice-words] starting PRODUCTION server (standalone build)"
  exec bun .next/standalone/server.js
fi

# Медленный путь: сборки нет — ставим зависимости, собираем и стартуем.
echo "[vice-words] no standalone build found — installing deps and building"
bun install || true
bun run db:push || true

if bun run build:standalone; then
  echo "[vice-words] production build ready — starting server"
  exec bun .next/standalone/server.js
fi

# Совсем страховка: сборка не удалась — отдаём dev-режим, чтобы приложение
# всё равно поднялось (медленно, но работает).
echo "[vice-words] build FAILED — falling back to dev mode"
exec node node_modules/.bin/next dev -p 3000
